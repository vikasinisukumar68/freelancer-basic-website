const express = require('express');
const mongoose = require('mongoose');
const http = require('http');
const path = require('path');
const bcrypt = require('bcrypt');

const app = express();
const PORT = process.env.PORT || 3001;

mongoose.connect('mongodb://127.0.0.1:27017/project')
    .then(() => {
        console.log('DATABASE CONNECTED');
    })
    .catch(err => {
        console.error('DATABASE CONNECTION ERROR:', err);
    });

    const UserSchema = new mongoose.Schema({
        name: String,
        password: String,
        confirmpassword: String, 
        mobile: String,
        email: String,
        gender: String,
        skills: String,
        experience: String,
        location: String,
        hourly_rate: String,
    });
    

const User = mongoose.model('User', UserSchema);

const ProjectSchema = new mongoose.Schema({
    title: String,
    description: String,
    budget: Number,
    deadline: Date,
});

const Project = mongoose.model('Project', ProjectSchema);

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'first.html'));
});


app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signupf.html'));
});


app.get('/signout', (req, res) => {
    res.redirect('/first.html');
});


app.post('/signupf', async (req, res) => {
    try {
        const { fullname, email, password, skills, experience, location, hourly_rate, age, mobile, gender, state } = req.body;
      
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send("User with this email already exists");
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({
            name: fullname,
            email,
            password: hashedPassword,
            skills,
            experience,
            location,
            hourly_rate,
            age,
            mobile,
            gender,
            state,
        });
        await newUser.save();
        res.redirect('/homef.html');
    } catch (error) {
        console.error('DATABASE INSERTION ERROR:', error);
        res.status(500).send("Error signing up user");
    }
});


app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        const user = await User.findOne({ email });
        if (user) {
            const match = await bcrypt.compare(password, user.password);
            if (match) {
                
                return res.redirect('/homef.html');
            } else {
                return res.status(401).send("Invalid email or password");
            }
        }
        
        
        return res.status(401).send("User not found");
        
    } catch (error) {
        console.error('LOGIN ERROR:', error);
        return res.status(500).send("Error logging in");
    }
});


app.get('/users', async (req, res) => {
    try {
        
        const users = await User.find({});
        
        res.json(users);
    } catch (error) {
        console.error('ERROR FETCHING USERS:', error);
        res.status(500).send("Error fetching users");
    }
});


app.post('/post', async (req, res) => {
    try {
        const { title, description, budget, deadline } = req.body;
        const newProject = new Project({
            title,
            description,
            budget,
            deadline: new Date(deadline),
        });
        await newProject.save();
       
        res.redirect('/homef.html');
    } catch (error) {
        console.error('DATABASE INSERTION ERROR:', error);
        res.status(500).send("Error posting project");
    }
});


app.get('/projects', async (req, res) => {
    try {
        const projects = await Project.find({});
        res.json(projects);
    } catch (error) {
        console.error('ERROR FETCHING PROJECTS:', error);
        res.status(500).send("Error fetching projects");
    }
});



app.get('/users', async (req, res) => {
    try {
        
        res.sendFile(path.join(__dirname, 'public', 'user.html'));
    } catch (error) {
        console.error('ERROR FETCHING USERS:', error);
        res.status(500).send("Error fetching users");
    }
});





app.listen(PORT, () => {
    console.log(`Express server started at http://localhost:${PORT}`);
});
